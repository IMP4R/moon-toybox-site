# Moon Toybox
Three downloadable forms: moon, truck, knot. Teddy is a website-only rendered demonstration and is not distributed in this library.
Truck: Low poly Stylized Truck by dehariyalokesh1998, CC BY 4.0, https://sketchfab.com/3d-models/0a78728c391044b29d06acc2d00ec87a ; https://creativecommons.org/licenses/by/4.0/ . Modified by normalization, SDF conversion and pearl rendering. See CREDITS.html.

## Performance 0.1.1
Native device density capped at 2x and 768px; no forced 3x supersampling. Decorative WebGL requires hardware acceleration; software renderers keep the original WebP instead of CPU raymarching. Animation callbacks stop entirely offscreen, in hidden tabs and under reduced motion. Visible animations are paced at up to 20fps. Teddy remains image-only; no teddy model or field is included.
