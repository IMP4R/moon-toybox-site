# Moon Toybox
Three downloadable forms: moon, truck, knot. Teddy is a website-only rendered demonstration and is not distributed in this library.
Truck: Low poly Stylized Truck by dehariyalokesh1998, CC BY 4.0, https://sketchfab.com/3d-models/0a78728c391044b29d06acc2d00ec87a ; https://creativecommons.org/licenses/by/4.0/ . Modified by normalization, SDF conversion and pearl rendering. See CREDITS.html.
